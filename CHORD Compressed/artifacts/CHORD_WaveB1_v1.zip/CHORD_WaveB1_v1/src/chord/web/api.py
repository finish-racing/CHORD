from __future__ import annotations
import json, tempfile
from pathlib import Path
from fastapi import FastAPI, Form, UploadFile, File, HTTPException
from chord.config import load_settings
from chord.logging_setup import configure_logging
from chord.utils.paths import ensure_runtime_dirs
from chord.utils.validation import validate_quiz_answers
from chord.db.session import make_session_factory, make_engine
from chord.db.base import Base
from chord.db import repositories as repo
from chord.domain.quiz import get_quiz_definition
from chord.services.run_service import ingest_playlist_file, submit_quiz_answers
from chord.services.feature_service import compute_wave_b1_aggregates

settings = load_settings(None)
configure_logging(settings)
ensure_runtime_dirs(settings)
session_factory = make_session_factory(settings)

api = FastAPI(title="CHORD Wave A API")

@api.on_event("startup")
def startup():
    engine = make_engine(settings)
    Base.metadata.create_all(engine)

@api.get("/health")
def health():
    return {"ok": True, "product": "CHORD", "wave": "A"}

@api.get("/quiz")
def quiz():
    return get_quiz_definition()

@api.get("/runs")
def runs():
    with session_factory() as session:
        items = repo.list_runs(session)
        return [{"id": x.id, "status": x.status, "mode": x.mode, "debug_enabled": x.debug_enabled} for x in items]

@api.post("/runs")
def create_run(mode: str = Form("analysis"), notes: str | None = Form(None)):
    with session_factory() as session:
        run = repo.create_run(session, mode=mode, debug_enabled=settings.debug.enabled, notes=notes)
        return {"run_id": run.id, "status": run.status}

@api.get("/runs/{run_id}/playlists")
def playlists(run_id: int):
    with session_factory() as session:
        items = repo.list_playlists_for_run(session, run_id)
        return [{"id": p.id, "playlist_name": p.playlist_name, "playlist_kind": p.playlist_kind, "source_order": p.source_order} for p in items]

@api.post("/runs/{run_id}/quiz")
def post_quiz(run_id: int, answers_json: str = Form(...)):
    answers = json.loads(answers_json)
    validate_quiz_answers(answers)
    with session_factory() as session:
        submit_quiz_answers(session, run_id=run_id, answers=answers)
        repo.update_run_status(session, run_id, "quiz_captured")
        return {"run_id": run_id, "status": "quiz_captured"}

@api.post("/runs/{run_id}/uploads")
async def upload_playlists(
    run_id: int,
    top25: UploadFile = File(...),
    playlists: list[UploadFile] = File(...),
):
    if not playlists:
        raise HTTPException(status_code=400, detail="At least one playlist upload is required.")
    tmpdir = Path(tempfile.mkdtemp(prefix="chord_wave_a_"))
    top25_path = tmpdir / top25.filename
    top25_path.write_bytes(await top25.read())
    playlist_paths = []
    for item in playlists:
        path = tmpdir / item.filename
        path.write_bytes(await item.read())
        playlist_paths.append(path)

    with session_factory() as session:
        repo.update_run_status(session, run_id, "importing")
        ingest_playlist_file(session, settings, run_id=run_id, file_path=str(top25_path), playlist_name=top25_path.stem, playlist_kind="top25", source_order=0)
        for idx, item in enumerate(playlist_paths, start=1):
            ingest_playlist_file(session, settings, run_id=run_id, file_path=str(item), playlist_name=item.stem, playlist_kind="playlist", source_order=idx)
        repo.update_run_status(session, run_id, "imported")
    return {"run_id": run_id, "status": "imported", "playlist_count": len(playlist_paths) + 1}


@api.post("/runs/{run_id}/aggregates")
def build_aggregates(run_id: int):
    with session_factory() as session:
        payload = compute_wave_b1_aggregates(session, settings, run_id=run_id)
        repo.update_run_status(session, run_id, "aggregates_built")
        return payload

@api.get("/runs/{run_id}/aggregates")
def get_aggregates(run_id: int):
    with session_factory() as session:
        item = repo.get_run_aggregate(session, run_id)
        if item is None:
            raise HTTPException(status_code=404, detail="Aggregate payload not found")
        return item.aggregate_payload
