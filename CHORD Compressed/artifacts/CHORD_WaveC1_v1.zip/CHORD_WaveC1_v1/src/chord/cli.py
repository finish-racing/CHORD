from __future__ import annotations
import json, logging
from pathlib import Path
import typer
from chord.config import load_settings
from chord.logging_setup import configure_logging
from chord.utils.paths import ensure_runtime_dirs
from chord.utils.validation import validate_quiz_answers
from chord.db.session import make_engine, make_session_factory
from chord.db.base import Base
from chord.db import repositories as repo
from chord.domain.quiz import get_quiz_definition
from chord.services.run_service import ingest_playlist_file, submit_quiz_answers
from chord.services.feature_service import compute_wave_b1_aggregates
from chord.services.enrichment_service import enrich_run
from chord.services.identity_service import build_identity_profile
from chord.services.prism_service import run_prism

app = typer.Typer(help="CHORD Ubuntu CLI")
logger = logging.getLogger(__name__)

def bootstrap(config_path: str | None = None):
    settings = load_settings(config_path)
    configure_logging(settings)
    ensure_runtime_dirs(settings)
    session_factory = make_session_factory(settings)
    return settings, session_factory

@app.command("initdb")
def initdb(config: str | None = typer.Option(None, help="Path to config TOML")):
    settings, _ = bootstrap(config)
    engine = make_engine(settings)
    Base.metadata.create_all(engine)
    typer.echo("Initialized CHORD database schema.")

@app.command("quiz")
def quiz():
    typer.echo(json.dumps(get_quiz_definition(), indent=2))

@app.command("create-run")
def create_run(config: str | None = typer.Option(None), mode: str = typer.Option("analysis"), notes: str | None = typer.Option(None)):
    settings, session_factory = bootstrap(config)
    with session_factory() as session:
        run = repo.create_run(session, mode=mode, debug_enabled=settings.debug.enabled, notes=notes)
        typer.echo(json.dumps({"run_id": run.id, "status": run.status}, indent=2))

@app.command("import-playlists")
def import_playlists(
    run_id: int = typer.Option(...),
    top25: str = typer.Option(..., help="Path to Top 25 Most Played export"),
    playlist: list[str] = typer.Option([], help="One or more playlist exports"),
    config: str | None = typer.Option(None),
):
    if not playlist:
        raise typer.BadParameter("At least one --playlist is required.")
    settings, session_factory = bootstrap(config)
    with session_factory() as session:
        repo.update_run_status(session, run_id, "importing")
        ingest_playlist_file(session, settings, run_id=run_id, file_path=top25, playlist_name=Path(top25).stem, playlist_kind="top25", source_order=0)
        for idx, item in enumerate(playlist, start=1):
            ingest_playlist_file(session, settings, run_id=run_id, file_path=item, playlist_name=Path(item).stem, playlist_kind="playlist", source_order=idx)
        repo.update_run_status(session, run_id, "imported")
    typer.echo("Imported Top 25 and playlist set.")

@app.command("submit-quiz")
def submit_quiz(
    run_id: int = typer.Option(...),
    answers_json: str = typer.Option(..., help='JSON object of quiz answers'),
    config: str | None = typer.Option(None),
):
    answers = json.loads(answers_json)
    validate_quiz_answers(answers)
    settings, session_factory = bootstrap(config)
    with session_factory() as session:
        profile = submit_quiz_answers(session, run_id=run_id, answers=answers)
        repo.update_run_status(session, run_id, "quiz_captured")
        typer.echo(json.dumps({"run_id": run_id, "profile_id": profile.id}, indent=2))

@app.command("list-runs")
def list_runs(config: str | None = typer.Option(None)):
    _, session_factory = bootstrap(config)
    with session_factory() as session:
        runs = repo.list_runs(session)
        typer.echo(json.dumps([
            {"id": r.id, "status": r.status, "mode": r.mode, "debug_enabled": r.debug_enabled}
            for r in runs
        ], indent=2))

@app.command("list-playlists")
def list_playlists(run_id: int = typer.Option(...), config: str | None = typer.Option(None)):
    _, session_factory = bootstrap(config)
    with session_factory() as session:
        playlists = repo.list_playlists_for_run(session, run_id)
        typer.echo(json.dumps([
            {"id": p.id, "playlist_name": p.playlist_name, "playlist_kind": p.playlist_kind, "source_order": p.source_order}
            for p in playlists
        ], indent=2))

if __name__ == "__main__":
    app()


@app.command("build-aggregates")
def build_aggregates(run_id: int = typer.Option(...), config: str | None = typer.Option(None)):
    settings, session_factory = bootstrap(config)
    with session_factory() as session:
        payload = compute_wave_b1_aggregates(session, settings, run_id=run_id)
        repo.update_run_status(session, run_id, "aggregates_built")
        typer.echo(json.dumps(payload, indent=2))

@app.command("show-aggregates")
def show_aggregates(run_id: int = typer.Option(...), config: str | None = typer.Option(None)):
    _, session_factory = bootstrap(config)
    with session_factory() as session:
        item = repo.get_run_aggregate(session, run_id)
        if item is None:
            raise typer.BadParameter(f"No aggregate payload found for run {run_id}")
        typer.echo(json.dumps(item.aggregate_payload, indent=2))


@app.command("enrich-run")
def enrich_run_command(run_id: int = typer.Option(...), config: str | None = typer.Option(None)):
    settings, session_factory = bootstrap(config)
    with session_factory() as session:
        payload = enrich_run(session, settings, run_id=run_id)
        repo.update_run_status(session, run_id, "enriched")
        typer.echo(json.dumps(payload, indent=2))

@app.command("show-enrichment")
def show_enrichment(run_id: int = typer.Option(...), config: str | None = typer.Option(None)):
    _, session_factory = bootstrap(config)
    with session_factory() as session:
        item = repo.get_run_enrichment_summary(session, run_id)
        if item is None:
            raise typer.BadParameter(f"No enrichment summary found for run {run_id}")
        typer.echo(json.dumps(item.summary_payload, indent=2))


@app.command("build-identity")
def build_identity(run_id: int = typer.Option(...), config: str | None = typer.Option(None)):
    settings, session_factory = bootstrap(config)
    with session_factory() as session:
        payload = build_identity_profile(session, settings, run_id=run_id)
        repo.update_run_status(session, run_id, "identity_built")
        typer.echo(json.dumps(payload, indent=2))

@app.command("show-identity")
def show_identity(run_id: int = typer.Option(...), config: str | None = typer.Option(None)):
    _, session_factory = bootstrap(config)
    with session_factory() as session:
        item = repo.get_identity_profile(session, run_id)
        if item is None:
            raise typer.BadParameter(f"No identity profile found for run {run_id}")
        typer.echo(json.dumps(item.profile_payload, indent=2))


@app.command("run-prism")
def run_prism_command(run_id: int = typer.Option(...), mode: str = typer.Option("balanced"), config: str | None = typer.Option(None)):
    settings, session_factory = bootstrap(config)
    with session_factory() as session:
        payload = run_prism(session, settings, run_id=run_id, mode=mode)
        repo.update_run_status(session, run_id, "prism_scored")
        typer.echo(json.dumps(payload["summary"], indent=2))

@app.command("show-prism")
def show_prism(run_id: int = typer.Option(...), mode: str = typer.Option("balanced"), config: str | None = typer.Option(None)):
    _, session_factory = bootstrap(config)
    with session_factory() as session:
        rec_set = repo.get_recommendation_set(session, run_id, mode)
        if rec_set is None:
            raise typer.BadParameter(f"No recommendation set found for run {run_id} and mode {mode}")
        items = repo.list_recommendation_items(session, rec_set.id)
        typer.echo(json.dumps({
            "summary": rec_set.summary_payload,
            "items": [
                {
                    "rank": x.rank,
                    "canonical_track_id": x.canonical_track_id,
                    "final_score": x.final_score,
                    "confidence_score": x.confidence_score,
                    "explanation_text": x.explanation_text,
                    "score_breakdown": x.score_breakdown,
                } for x in items
            ]
        }, indent=2))
