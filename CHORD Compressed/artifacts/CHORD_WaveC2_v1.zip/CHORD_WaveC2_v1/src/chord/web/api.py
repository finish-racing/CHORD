from __future__ import annotations
import json, tempfile
from pathlib import Path
from fastapi import FastAPI, Form, UploadFile, File, HTTPException
from chord.config import load_settings
from chord.logging_setup import configure_logging
from chord.utils.paths import ensure_runtime_dirs
from chord.utils.validation import validate_quiz_answers
from chord.db.session import make_session_factory, make_engine
from chord.db.base import Base
from chord.db import repositories as repo
from chord.domain.quiz import get_quiz_definition
from chord.services.run_service import ingest_playlist_file, submit_quiz_answers
from chord.services.feature_service import compute_wave_b1_aggregates
from chord.services.enrichment_service import enrich_run
from chord.services.identity_service import build_identity_profile
from chord.services.prism_service import run_prism
from chord.services.curated_playlist_service import build_curated_playlist

settings = load_settings(None)
configure_logging(settings)
ensure_runtime_dirs(settings)
session_factory = make_session_factory(settings)

api = FastAPI(title="CHORD Wave A API")

@api.on_event("startup")
def startup():
    engine = make_engine(settings)
    Base.metadata.create_all(engine)

@api.get("/health")
def health():
    return {"ok": True, "product": "CHORD", "wave": "A"}

@api.get("/quiz")
def quiz():
    return get_quiz_definition()

@api.get("/runs")
def runs():
    with session_factory() as session:
        items = repo.list_runs(session)
        return [{"id": x.id, "status": x.status, "mode": x.mode, "debug_enabled": x.debug_enabled} for x in items]

@api.post("/runs")
def create_run(mode: str = Form("analysis"), notes: str | None = Form(None)):
    with session_factory() as session:
        run = repo.create_run(session, mode=mode, debug_enabled=settings.debug.enabled, notes=notes)
        return {"run_id": run.id, "status": run.status}

@api.get("/runs/{run_id}/playlists")
def playlists(run_id: int):
    with session_factory() as session:
        items = repo.list_playlists_for_run(session, run_id)
        return [{"id": p.id, "playlist_name": p.playlist_name, "playlist_kind": p.playlist_kind, "source_order": p.source_order} for p in items]

@api.post("/runs/{run_id}/quiz")
def post_quiz(run_id: int, answers_json: str = Form(...)):
    answers = json.loads(answers_json)
    validate_quiz_answers(answers)
    with session_factory() as session:
        submit_quiz_answers(session, run_id=run_id, answers=answers)
        repo.update_run_status(session, run_id, "quiz_captured")
        return {"run_id": run_id, "status": "quiz_captured"}

@api.post("/runs/{run_id}/uploads")
async def upload_playlists(
    run_id: int,
    top25: UploadFile = File(...),
    playlists: list[UploadFile] = File(...),
):
    if not playlists:
        raise HTTPException(status_code=400, detail="At least one playlist upload is required.")
    tmpdir = Path(tempfile.mkdtemp(prefix="chord_wave_a_"))
    top25_path = tmpdir / top25.filename
    top25_path.write_bytes(await top25.read())
    playlist_paths = []
    for item in playlists:
        path = tmpdir / item.filename
        path.write_bytes(await item.read())
        playlist_paths.append(path)

    with session_factory() as session:
        repo.update_run_status(session, run_id, "importing")
        ingest_playlist_file(session, settings, run_id=run_id, file_path=str(top25_path), playlist_name=top25_path.stem, playlist_kind="top25", source_order=0)
        for idx, item in enumerate(playlist_paths, start=1):
            ingest_playlist_file(session, settings, run_id=run_id, file_path=str(item), playlist_name=item.stem, playlist_kind="playlist", source_order=idx)
        repo.update_run_status(session, run_id, "imported")
    return {"run_id": run_id, "status": "imported", "playlist_count": len(playlist_paths) + 1}


@api.post("/runs/{run_id}/aggregates")
def build_aggregates(run_id: int):
    with session_factory() as session:
        payload = compute_wave_b1_aggregates(session, settings, run_id=run_id)
        repo.update_run_status(session, run_id, "aggregates_built")
        return payload

@api.get("/runs/{run_id}/aggregates")
def get_aggregates(run_id: int):
    with session_factory() as session:
        item = repo.get_run_aggregate(session, run_id)
        if item is None:
            raise HTTPException(status_code=404, detail="Aggregate payload not found")
        return item.aggregate_payload


@api.post("/runs/{run_id}/enrich")
def enrich_run_route(run_id: int):
    with session_factory() as session:
        payload = enrich_run(session, settings, run_id=run_id)
        repo.update_run_status(session, run_id, "enriched")
        return payload

@api.get("/runs/{run_id}/enrichment")
def get_enrichment(run_id: int):
    with session_factory() as session:
        item = repo.get_run_enrichment_summary(session, run_id)
        if item is None:
            raise HTTPException(status_code=404, detail="Enrichment summary not found")
        return item.summary_payload


@api.post("/runs/{run_id}/identity")
def build_identity_route(run_id: int):
    with session_factory() as session:
        payload = build_identity_profile(session, settings, run_id=run_id)
        repo.update_run_status(session, run_id, "identity_built")
        return payload

@api.get("/runs/{run_id}/identity")
def get_identity(run_id: int):
    with session_factory() as session:
        item = repo.get_identity_profile(session, run_id)
        if item is None:
            raise HTTPException(status_code=404, detail="Identity profile not found")
        return item.profile_payload


@api.post("/runs/{run_id}/prism")
def run_prism_route(run_id: int, mode: str = "balanced"):
    with session_factory() as session:
        payload = run_prism(session, settings, run_id=run_id, mode=mode)
        repo.update_run_status(session, run_id, "prism_scored")
        return payload

@api.get("/runs/{run_id}/prism")
def get_prism(run_id: int, mode: str = "balanced"):
    with session_factory() as session:
        rec_set = repo.get_recommendation_set(session, run_id, mode)
        if rec_set is None:
            raise HTTPException(status_code=404, detail="Recommendation set not found")
        items = repo.list_recommendation_items(session, rec_set.id)
        return {
            "summary": rec_set.summary_payload,
            "items": [
                {
                    "rank": x.rank,
                    "canonical_track_id": x.canonical_track_id,
                    "final_score": x.final_score,
                    "confidence_score": x.confidence_score,
                    "explanation_text": x.explanation_text,
                    "score_breakdown": x.score_breakdown,
                } for x in items
            ]
        }


@api.post("/runs/{run_id}/curated")
def build_curated_route(run_id: int, mode: str = "balanced", length: int = 60):
    with session_factory() as session:
        payload = build_curated_playlist(session, settings, run_id=run_id, mode=mode, requested_length=length)
        repo.update_run_status(session, run_id, "curated_built")
        return payload

@api.get("/runs/{run_id}/curated")
def get_curated(run_id: int, mode: str = "balanced"):
    with session_factory() as session:
        cp_set = repo.get_curated_playlist_set(session, run_id, mode)
        if cp_set is None:
            raise HTTPException(status_code=404, detail="Curated playlist not found")
        items = repo.list_curated_playlist_items(session, cp_set.id)
        return {
            "summary": cp_set.summary_payload,
            "items": [
                {
                    "rank": x.rank,
                    "canonical_track_id": x.canonical_track_id,
                    "source_type": x.source_type,
                    "role_label": x.role_label,
                    "inclusion_reason": x.inclusion_reason,
                    "score_payload": x.score_payload,
                } for x in items
            ]
        }
